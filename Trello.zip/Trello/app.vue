<template>
  <div class="p-10 h-[100vh] bg-teal-600 overlow-auto">
    <h1 class="text-4xl text-white flex items-center mb-10">
      Nuevo Peco Trello Board
    </h1>
    <TrelloBoard />
  </div>
</template>