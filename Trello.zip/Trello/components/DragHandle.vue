<template>
  <span class="drag-handle cursor-move"> ⠋ </span>
</template>
